import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-symp-info',
  templateUrl: './symp-info.component.html',
  styleUrls: ['./symp-info.component.css']
})
export class SympInfoComponent implements OnInit {

  symptoms : any[] = [];
  dataSource =  new MatTableDataSource();
  displayedColumns : string[] = ["symName", "desc", "comCau"];

  constructor(public dialogRef: MatDialogRef<SympInfoComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
    this.symptoms[0] = data.symp
    this.dataSource.data = this.symptoms
   }

  ngOnInit(): void {
  }

  close() : void{
    this.dialogRef.close()
  }

}
