import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SympInfoComponent } from './symp-info.component';

describe('SympInfoComponent', () => {
  let component: SympInfoComponent;
  let fixture: ComponentFixture<SympInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SympInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SympInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
