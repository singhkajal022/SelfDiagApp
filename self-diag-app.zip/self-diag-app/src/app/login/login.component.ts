import { Component, OnInit, Output, EventEmitter, Inject } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup, FormControl, Validators } from '@angular/forms'; 
import { LoregService } from './loreg.service';
import { DataShareService } from '../data-share.service';
import { ToastrService } from 'ngx-toastr';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ForgotComponent } from './forgot/forgot.component';

export class Gender{
  gen : string = "";
  val : string = ""
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  userName: string = "Login/Signup";
  @Output() userNameEmitter = new EventEmitter<any>();
  login : boolean = true;
  regi : boolean = false;
  hide : boolean = true;
  editUser : boolean = false;
  logUser : any = {};
  userDetails : any = {}
  gender : Gender[] = [{gen : "Male", val : "M"},
                       {gen : "Female", val : "F"},
                       {gen : "Other", val : "O"}]
  secques : string[] = ["What is the name of your First School",
                        "What is the name of your First Pet",
                        "What is your Favourite Holiday Destination",
                        "What is the Name of your Favourite Singer",
                        "What is your Mother's Maiden Name",
                        "What is the brand of the car you first owned",
                        "What is your Father's Birth Place"]
  loginForm = new FormGroup({
    loginId: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
  });
  regiForm = new FormGroup({
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    gender: new FormControl('', Validators.required),
    age: new FormControl('', Validators.required),
    dob : new FormControl('', Validators.required),
    address : new FormControl('', Validators.required),
    email : new FormControl('', Validators.required),
    loginId : new FormControl('', Validators.required),
    password : new FormControl('', Validators.required),
    secque1 : new FormControl('', Validators.required),
    secque2 : new FormControl('', Validators.required),
    secans1 : new FormControl('', Validators.required),
    secans2 : new FormControl('', Validators.required) 
  });

  constructor( private loreg : LoregService, private router: Router, private dataShareService : DataShareService, private toastr : ToastrService, public dialog: MatDialog) { }

  ngOnInit(): void {
    this.dataShareService.login.subscribe(result => {
      console.log(result)
      if (result.regi){
        this.userDetails = result; 
        this.editUser = true;
        this.regiForm.get("firstName")?.setValue(this.userDetails.firstName)
        this.regiForm.get("lastName")?.setValue(this.userDetails.lastName)
        this.regiForm.get("gender")?.setValue(this.userDetails.gender)
        this.regiForm.get("age")?.setValue(this.userDetails.age)
        this.regiForm.get("dob")?.setValue(this.userDetails.dob)
        this.regiForm.get("address")?.setValue(this.userDetails.address)
        this.regiForm.get("email")?.setValue(this.userDetails.email)
        this.regiForm.get("password")?.setValue(this.userDetails.password)
        this.regiForm.get("loginId")?.setValue(this.userDetails.loginId)
        this.regiForm.get("secque1")?.setValue(this.userDetails.secque1)
        this.regiForm.get("secque2")?.setValue(this.userDetails.secque2)
        this.regiForm.get("secans1")?.setValue(this.userDetails.secans1)
        this.regiForm.get("secans2")?.setValue(this.userDetails.secans2)
        this.regi = true;
        this.login = false;
      }
    });

    this.dataShareService.signOut.subscribe(result => {
      console.log(result)
      if(result == "SignOut"){
        this.login = true;
        this.regi = false;
      }
    })
  }
  

  register() : void{
    this.login = false;
    this.regi = true;
  }

  createAccount() : void{
    if(this.regiForm.status != "INVALID"){
      this.loreg.createAccount(this.regiForm.value).subscribe(data =>{
        console.log(data)
        this.toastr.success("Please Login", "Account created successfully" )
        this.login = true;
        this.regi = false;
      })
    }
    else{
      this.toastr.error( "Please fill all the details" , "Form Incomplete" )
    }
  }

  auth() : void{
    if(this.loginForm.status != "INVALID"){
      this.loreg.auth(this.loginForm.value).subscribe(data =>{
        if(Object.keys(data)[0] != "Error"){
          this.userDetails = data;
          this.userDetails.loggedIn = true;
          this.userName = this.userDetails.firstName + " " + this.userDetails.lastName
          this.userNameEmitter.emit(this.userDetails);
          delete this.userDetails.loggedIn;
          this.dataShareService.changeLogin(this.userDetails); 
        }
        else{
          this.toastr.error( data.Error, "Error Occured" )
        }
      })
    }
    else{
      this.toastr.error("Please fill all the details" , "Form Incomplete")
    }
  }

  forgot() : void{

    const dialogRef = this.dialog.open(ForgotComponent, {
      width: "382px",
      height: "550px",
      data: { animal: 'panda' }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log(result);
    });
   
  }

  update() : void{
    this.loreg.update(this.regiForm.value).subscribe(data =>{
      data
      this.userDetails = data
      this.userNameEmitter.emit(this.userDetails);
      this.dataShareService.changeLogin(this.userDetails); 
      this.toastr.success("Details updated successfully.")
    })

  }

  resetLogin() : void{
    this.loginForm.reset()
  }

  resetRegi() : void{
    this.regiForm.reset()
  }

  goBack() : void{
    this.login = true;
    this.regi = false;
  }

  cancel() : void{
    delete this.userDetails.regi;
    this.userNameEmitter.emit(this.userDetails); 
    this.dataShareService.changeLogin(this.userDetails); 
  }

 

}
