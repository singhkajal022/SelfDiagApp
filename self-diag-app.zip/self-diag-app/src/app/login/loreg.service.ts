import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoregService {

  constructor(private http : HttpClient) { }

  loginurl : string = "http://127.0.0.1:5000/login";
  regiurl : string = "http://127.0.0.1:5000/regi";
  updateurl : string = "http://127.0.0.1:5000/edit";
  forgoturl : string = "http://127.0.0.1:5000/forgot";
  uptpwdurl : string = "http://127.0.0.1:5000/uptpwd";

  auth(loginForm : any) : Observable<any> {
    return this.http.post<any[]>(this.loginurl , loginForm);
  }

  createAccount(regiForm : any) : Observable<any> {
    return this.http.post<any[]>(this.regiurl , regiForm);
  }

  update(regiForm : any) : Observable<any> {
    return this.http.post<any[]>(this.updateurl , regiForm);
  }

  forgot(detailsForm : any) : Observable<any> {
    return this.http.post<any[]>(this.forgoturl , detailsForm);
  }

  updtPass(detailsForm : any) : Observable<any>{
    return this.http.post<any[]>(this.uptpwdurl , detailsForm);
  }
  

}
