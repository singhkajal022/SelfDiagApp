import { TestBed } from '@angular/core/testing';

import { LoregService } from './loreg.service';

describe('LoregService', () => {
  let service: LoregService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoregService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
