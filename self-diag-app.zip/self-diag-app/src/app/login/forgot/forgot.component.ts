import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr'; 
import { LoregService } from '../loreg.service';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css']
})
export class ForgotComponent implements OnInit {

  secque1 : string = "";
  secque2 : string = "";
  firStep : boolean = true;
  secques : boolean = false;
  laStep : boolean = false;
  userDetails : any = {};
  pass : boolean = false;
  log : boolean = false;
  hide : boolean = true;
  ftpsForm = new FormGroup({
    loginId: new FormControl(false, Validators.required),
    password: new FormControl(false, Validators.required),
    email : new FormControl('', Validators.required),
    secque1 : new FormControl('', Validators.required),
    secans1 : new FormControl('', Validators.required),
    secque2 : new FormControl('', Validators.required),
    secans2 : new FormControl('', Validators.required),
    newpass : new FormControl('', Validators.required)
  });

  
  constructor(public dialogRef: MatDialogRef<ForgotComponent>, @Inject(MAT_DIALOG_DATA) public data: any, private toastr : ToastrService, private loregService : LoregService) { 
      data
    }

  ngOnInit(): void {

  }

  /*
  onNoClick(): void {
    this.dialogRef.close();
  }
  */

  proceed() : void{
    if(this.ftpsForm.value.secans1 != "" && this.ftpsForm.value.secans2 != ""){
      if(this.ftpsForm.value.secans1 == this.userDetails.secans1 && this.ftpsForm.value.secans2 == this.userDetails.secans2){
        this.firStep = false;
        this.secques =  false;
        if(this.ftpsForm.value.password  && this.ftpsForm.value.loginId ){
          this.pass = true;
          this.log = true;
        }
        else{
          if(this.ftpsForm.value.password){
            this.pass = true;
            this.log = false;
          }
          else{
            if(this.ftpsForm.value.loginId){
              this.pass = false;
              this.log = true;
            }
          }
        }
      }
      else{
        this.toastr.warning("Answers to the security questions are incorrect. Please give correct answers to update password", "Cannot proceed further")
      }
    }
    else{
      if (this.ftpsForm.value.secans1 == "" && this.ftpsForm.value.secans2 == ""){
        this.toastr.warning("Please give answers to proceed further", "Annswers to both the security questions left blank")
      }
      else{
        if(this.ftpsForm.value.secans1 == ""){
          this.toastr.warning("Please give answer to proceed further", "Annswers to  security question 1 left blank")
        }
        else{
          if(this.ftpsForm.value.secans2 == ""){
            this.toastr.warning("Please give answer to proceed further", "Annswers to  security question 2 left blank")
          }
        }
      }
    }
  }

  getDetails() : void{
    if(!(this.ftpsForm.value.loginId || this.ftpsForm.value.password)){
      this.toastr.warning("Choose at least one to proceed ahead", "None of the options chosen")
    }
    else{
      if(this.ftpsForm.value.email == ""){
        this.toastr.warning("Please enter Email Id to proceed ahead", "Email Id left blank")
      }
      else{
        let details = { loginId : this.ftpsForm.value.loginId,
                        password : this.ftpsForm.value.password,
                        email : this.ftpsForm.value.email
        }
        this.loregService.forgot(details).subscribe(data => {
          this.userDetails = data;      
          this.secque1 = this.userDetails.secque1
          this.secque2 = this.userDetails.secque2
          this.firStep = false;
          this.secques = true;
          this.laStep = false;
        })
      }
    }
  }

  updtPass() : void{
    if(this.ftpsForm.value.newpass != ""){
      let details = {
        loginId : this.userDetails.loginId,
        email : this.userDetails.email,
        password : this.ftpsForm.value.newpass
      }
      this.loregService.updtPass(details).subscribe( data => {
          console.log(data);
          this.toastr.success("Please login to know your health status","Password updated successfully");
          this.dialogRef.close();
      })
    }
    else{
      this.toastr.warning("Please enter new password", "New Password Left Blank ")
    }
  }

  closeDialog() : void{
    this.dialogRef.close();
  }

}
