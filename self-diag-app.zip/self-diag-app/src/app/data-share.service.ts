import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject, BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataShareService {

  constructor(private http : HttpClient) { }

  private loginSource = new BehaviorSubject<any>({});
  login = this.loginSource.asObservable()

  private signOutSource = new BehaviorSubject<string>("SignIn");
  signOut = this.signOutSource.asObservable()

  private sendSympSource = new BehaviorSubject<any>({});
  sendSymp = this.sendSympSource.asObservable()

  sympsurl : string = "http://127.0.0.1:5000/symps";

  changeLogin(login: any) {
    this.loginSource.next(login);
  }

  logout(signOut : any){
    this.signOutSource.next(signOut);
  }

  getSymptoms() : Observable<any>{
    return this.http.get(this.sympsurl);
  }

  sendSymps(sendSymp : any){
    this.sendSympSource.next(sendSymp);
  }


}
