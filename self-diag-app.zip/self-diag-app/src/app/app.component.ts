import { Component } from '@angular/core';
import { DataShareService } from './data-share.service';
import { ToastrService } from 'ngx-toastr';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SympInfoComponent } from './symp-info/symp-info.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  appName : string = "Self Diagnosis";
  userName : string = "Login/Signup";
  landing : boolean = true;
  login : boolean = false;
  register : boolean = false;
  userDetails : any = {};
  editSignout : string[] = ["Manage Profile", "Sign Out"]
  loggedIn : boolean = false;
  selectedOpt : string = "";
  symps : boolean = false;
  sydecocau : any = {};
  allSymps : any[] = [];
  selectedSymp : any  = {};
  
  constructor(private dataShareService : DataShareService, private toastr : ToastrService, public dialog: MatDialog){
    this.dataShareService.getSymptoms().subscribe( data => {
      this.allSymps = data;
      if(data.length != 0){
        let len = data.length;
        let fsydecocau = data.slice(0,len/2)
        let ssydecocau = data.slice(len/2,len)
        console.log("fsydecocau")
        console.log(fsydecocau.length)
        console.log("ssydecocau")
        console.log(ssydecocau.length)
        this.sydecocau = {"fsydecocau" : fsydecocau,
                          "ssydecocau" : ssydecocau}
      } 
    })
  }

  ngOninit(): void{
    
  }

  recieveUserName($event : any) {
    this.userDetails = $event;
    this.userName = this.userDetails.firstName + " " + this.userDetails.lastName
    this.login = false;
    this.register = false;
    this.landing = true;
    this.loggedIn = true;
    this.symps = false;
  }

  recieveHomeInfo($event : any) {
    let homeInfo = $event;
    this.login = homeInfo.login;
    this.register = false;
    this.landing = homeInfo.landing;
    this.symps = homeInfo.symps;
  }

  getLogin() : void{
    this.login = true;
    this.landing = false;
    this.register = false;
    this.symps = false;
  }

  redLogin($event : any){
    this.login = true;
    this.register = false;
    this.landing = false;
    this.symps = false;
  }
 
    mgsgn(val : string){
    if(val == "sgnout"){
      this.userName = "Login/Signup";
      this.login = true;
      this.register = false;
      this.landing = false;
      this.loggedIn = false;
      this.symps = false;
      this.dataShareService.logout("SignOut");
      this.toastr.success("Please login to proceed ahead." , "Logged Out Successufully.")
    }
    else{
      if(val == "mgpr"){
        this.userDetails.regi = true
        this.dataShareService.changeLogin(this.userDetails);
        this.login = true;
        this.register = false;
        this.landing = false;
        this.symps = false;
      }
    }
  }

  symptoms() : void{
    this.login = false;
    this.register = false;
    this.landing = false;
    this.symps = true;
    this.dataShareService.sendSymps(this.sydecocau)  
  }

  openSymp(symp : any) : void{
    this.dialog.open(SympInfoComponent, {
      data: {
        symp : symp,
      }
    });

  }

}
