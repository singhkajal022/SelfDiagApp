import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import { LandingService } from './landing.service';
import { range } from 'rxjs';
import { DataShareService } from '../data-share.service';
import { ToastrService } from 'ngx-toastr';
import { MatTableDataSource } from '@angular/material/table';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import autoTable from 'jspdf-autotable'
import { ThemePalette } from '@angular/material/core';
import { ProgressSpinnerMode } from '@angular/material/progress-spinner';

export class SympSev{
  Symp : string = "";
  SympName  : string = "";
}

export class Gender{
  gen : string = "";
  value : number = 0;
}

export class Result{
  dis : string = "";
  res : string = ""
}

export interface Report {
  can : string;
  cov : string;
  dis : string;
  desc : string;
  precs : string;
  dt : number;
}

export class Reports {
  reps : Report[] = [];
}

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.css'],
   providers: [
    /*{
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue : {
        showError : true,
        displayDefaultIndicatorType : false
      }
    }*/
  ] 
})

export class LandingPageComponent implements OnInit {
  notLogin : string = "You have not Logged In. Please Login to get detailed Health Report";
  @Output() loginEmitter = new EventEmitter<string>();
  userName: string = "";
  isLinear = false;
  completed = false;
  spin : boolean = false;
  firstFormGroup : FormGroup;
  secondFormGroup : FormGroup; 
  thirdFormGroup : FormGroup;
  userDetails : any = {};
  selSymp : SympSev[] = [];
  selectall: boolean = false;
  can_par: number[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  ages : number[] = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100] ;
  genders : Gender[] = [{gen : "Male", value : 1},{gen : "Female", value : 2}];
  cov_par: number[] = [0, 1];
  displayedColumns: string[] = ["can", "cov", "dis", "desc", "precs", "dt"];
  dataSource =  new MatTableDataSource();
  dataSource1 =  new MatTableDataSource();
  showPre : boolean = false;
  showReport : boolean = false;
  report : Report[] = [];
  reports : any[] = [];
  repnum : number = 0;
  result : Result[] = [{dis : "Disease", res : "None"},
                       {dis : "Cancer", res : "Not Applicable"},
                       {dis : "Covid-19", res : "Not Applicable"},
                       {dis : "Dynamic Trust", res : "2"}];
  Symptoms: SympSev[] = [
    {Symp : "itching", SympName : "Itching"}, 
    {Symp : "skin_rash", SympName : "Skin Rashes"},
    {Symp : "nodal_skin_eruptions", SympName : "Skin Eruptions"},
    {Symp : "continuous_sneezing", SympName : "Countinuous Sneezing"}, 
    {Symp : "shivering", SympName : "Shivering"},
    {Symp : "chills", SympName : "Chills"},
    {Symp : "joint_pain", SympName : "Joint Pain"}, 
    {Symp : "stomach_pain", SympName : "Stomach Pain"},
    {Symp : "acidity", SympName : "Acidity"},
    {Symp : "ulcers_on_tongue", SympName : "Ulcers on Tongue"}, 
    {Symp : "muscle_wasting", SympName : "Muscle Wasting"},
    {Symp : "vomiting", SympName : "Vomiting"},
    {Symp : "burning_micturition", SympName : "Burning Micturition"}, 
    {Symp : "spotting_urination", SympName : "Spotting Urination"},
    {Symp : "fatigue", SympName : "Fatigue"},
    {Symp : "weight_gain", SympName : "Weight Gain"}, 
    {Symp : "anxiety", SympName : "Anxiety"},
    {Symp : "cold_hands_and_feets", SympName : "Cold hands and feets"},
    {Symp : "mood_swings", SympName : "Mood Swings"}, 
    {Symp : "weight_loss", SympName : "Weight Loss"},
    {Symp : "restlessness", SympName : "Restlessness"},
    {Symp : "lethargy", SympName : "Lethargy"}, 
    {Symp : "patches_in_throat", SympName : "Patches In Throat"},
    {Symp : "irregular_sugar_level", SympName : "Irregular Sugar Level"},
    {Symp : "cough", SympName : "Cough"}, 
    {Symp : "high_fever", SympName : "High Fever"},
    {Symp : "sunken_eyes", SympName : "Sunken Eyes"},
    {Symp : "breathlessness", SympName : "Breathlessness"}, 
    {Symp : "sweating", SympName : "Sweating"},
    {Symp : "dehydration", SympName : "Dehydration"},
    {Symp : "indigestion", SympName : "Indigestion"}, 
    {Symp : "headache", SympName : "Headache"},
    {Symp : "yellowish_skin", SympName : "Yellowish Skin"},
    {Symp : "dark_urine", SympName : "Dark Urine"}, 
    {Symp : "nausea", SympName : "Nausea"},
    {Symp : "loss_of_appetite", SympName : "Loss of Appetite"},
    {Symp : "pain_behind_the_eyes", SympName : "Pain behind the eyes"}, 
    {Symp : "back_pain", SympName : "Back pain"},
    {Symp : "constipation", SympName : "Constipation"},
    {Symp : "abdominal_pain", SympName : "Abdominal Pain"}, 
    {Symp : "diarrhoea", SympName : "Diarrhoea"},
    {Symp : "mild_fever", SympName : "Mild Fever"},
    {Symp : "yellow_urine", SympName : "Yellow Urine"}, 
    {Symp : "yellowing_of_eyes", SympName : "Yellowing of eyes"},
    {Symp : "acute_liver_failure", SympName : "Acute liver failure"},
    {Symp : "swelling_of_stomach", SympName : "Swelling of stomach"}, 
    {Symp : "swelled_lymph_nodes", SympName : "Swelled lymph nodes"},
    {Symp : "malaise", SympName : "Malaise"},
    {Symp : "blurred_and_distorted_vision", SympName : "Blurred and distorted vision"},
    {Symp : "phlegm", SympName : "Phlegm"},
    {Symp : "throat_irritation", SympName : "Throat Irritation"}, 
    {Symp : "redness_of_eyes", SympName : "Redness of eyes"},
    {Symp : "sinus_pressure", SympName : "Sinus Pressure"},
    {Symp : "runny_nose", SympName : "Runny Nose"}, 
    {Symp : "congestion", SympName : "Congestion"},
    {Symp : "chest_pain", SympName : "Chest Pain"},
    {Symp : "weakness_in_limbs", SympName : "Weakness in Limbs"}, 
    {Symp : "fast_heart_rate", SympName : "Fast Heart Rate"},
    {Symp : "pain_during_bowel_movements", SympName : "Pain during bowel movements"},
    {Symp : "pain_in_anal_region", SympName : "Pain in anal region"}, 
    {Symp : "bloody_stool", SympName : "Bloody stool"},
    {Symp : "irritation_in_anus", SympName : "Irritation in anus"},
    {Symp : "neck_pain", SympName : "Neck Pain"}, 
    {Symp : "dizziness", SympName : "Dizziness"},
    {Symp : "cramps", SympName : "Cramps"},
    {Symp : "bruising", SympName : "Bruising"}, 
    {Symp : "obesity", SympName : "obesity"},
    {Symp : "swollen_legs", SympName : "Swollen Legs"},
    {Symp : "swollen_blood_vessels", SympName : "Swollen blood vessels"}, 
    {Symp : "puffy_face_and_eyes", SympName : "Puffy face and eyes"},
    {Symp : "enlarged_thyroid", SympName : "Enlarged Thyroid"},
    {Symp : "brittle_nails", SympName : "Brittle Nails"}, 
    {Symp : "swollen_extremeties", SympName : "Swollen Extremeties"},
    {Symp : "excessive_hunger", SympName : "Excessive Hunger"},
    {Symp : "extra_marital_contacts", SympName : "Extra Marital Contacts"},
    {Symp : "drying_and_tingling_lips", SympName : "Drying and tingling lips"},
    {Symp : "slurred_speech", SympName : "Slurred speech"}, 
    {Symp : "knee_pain", SympName : "Knee pain"},
    {Symp : "hip_joint_pain", SympName : "Hip joint pain"},
    {Symp : "muscle_weakness", SympName : "Muscle weakness"}, 
    {Symp : "stiff_neck", SympName : "Stiff neck"},
    {Symp : "swelling_joints", SympName : "Swelling joints"},
    {Symp : "movement_stiffness", SympName : "Movement stiffness"}, 
    {Symp : "spinning_movements", SympName : "Spinning movements"},
    {Symp : "loss_of_balance", SympName : "Loss of balance"},
    {Symp : "unsteadiness", SympName : "Unsteadiness"}, 
    {Symp : "weakness_of_one_body_side", SympName : "Weakness of one body side"},
    {Symp : "loss_of_smell", SympName : "Loss of smell"},
    {Symp : "bladder_discomfort", SympName : "Bladder Discomfort"}, 
    {Symp : "foul_smell_ofurine", SympName : "Foul smell of urine"},
    {Symp : "continuous_feel_of_urine", SympName : "Continuous feel of urine"},
    {Symp : "passage_of_gases", SympName : "Passage of Gases"}, 
    {Symp : "internal_itching", SympName : "Internal Itching"},
    {Symp : "toxic_look_(typhos)", SympName : "Toxic look (typhos)"},
    {Symp : "depression", SympName : "Depression"}, 
    {Symp : "irritability", SympName : "Irritability"},
    {Symp : "muscle_pain", SympName : "Muscle Pain"},
    {Symp : "altered_sensorium", SympName : "Altered Sensorium"}, 
    {Symp : "red_spots_over_body", SympName : "Red Spots Over Body"},
    {Symp : "belly_pain", SympName : "Belly Pain"},
    {Symp : "abnormal_menstruation", SympName : "Abnormal Menstruation"}, 
    {Symp : "dischromic_patches", SympName : "Dischromic patches"},
    {Symp : "watering_from_eyes", SympName : "Watering from eyes"},
    {Symp : "increased_appetite", SympName : "Increased Appetite"}, 
    {Symp : "polyuria", SympName : "Polyuria"},
    {Symp : "family_history", SympName : "Family History"},
    {Symp : "mucoid_sputum", SympName : "Mucoid Sputum"},
    {Symp : "rusty_sputum", SympName : "Rusty Sputum"}, 
    {Symp : "lack_of_concentration", SympName : "Lack of Concentration"},
    {Symp : "visual_disturbances", SympName : "Visual Disturbances"},
    {Symp : "receiving_blood_transfusion", SympName : "Receiving Blood Transfusion"}, 
    {Symp : "receiving_unsterile_injections", SympName : "Receiving Unsterile Injections"},
    {Symp : "coma", SympName : "Coma"},
    {Symp : "stomach_bleeding", SympName : "Stomach Bleeding"}, 
    {Symp : "distention_of_abdomen", SympName : "Distention of Abdomen"},
    {Symp : "history_of_alcohol_consumption", SympName : "History of Alcohol Consumption"},
    {Symp : "fluid_overload", SympName : "Fluid Overload"}, 
    {Symp : "blood_in_sputum", SympName : "Blood In Sputum"},
    {Symp : "prominent_veins_on_calf", SympName : "Prominent Veins On Calf"},
    {Symp : "palpitations", SympName : "Palpitations"}, 
    {Symp : "painful_walking", SympName : "Painful Walking"},
    {Symp : "pus_filled_pimples", SympName : "Pus filled pimples"},
    {Symp : "blackheads", SympName : "Blackheads"},
    {Symp : "scurring", SympName : "Scurring"}, 
    {Symp : "skin_peeling", SympName : "Skin Peeling"},
    {Symp : "silver_like_dusting", SympName : "Silver like dusting"},
    {Symp : "small_dents_in_nails", SympName : "Small dents in nails"}, 
    {Symp : "inflammatory_nails", SympName : "Inflammatory nails"},
    {Symp : "blister", SympName : "Blister"},
    {Symp : "red_sore_around_nose", SympName : "Red sore around nose"}, 
    {Symp : "yellow_crust_ooze", SympName : "Yellow crust ooze"},
    {Symp : "prognosis", SympName : "Prognosis"}
  ];

  constructor(private builder: FormBuilder, private landingService : LandingService, private dataShareService : DataShareService, private toastr : ToastrService) {

    this.firstFormGroup = builder.group({
      /* isNotEmpty : [
        '',
        Validators.compose(
          [Validators.required]
        )
      ], */
      selSymp :  new FormControl([],Validators.required)

    });
    
    this.secondFormGroup = builder.group({
      age : new FormControl(30,Validators.required),
      gender : new FormControl(1,Validators.required),
      air_poll: new FormControl(1,Validators.required),
      alc_use: new FormControl(1,Validators.required),
      dust_all : new FormControl(1,Validators.required),
      occ_Haz : new FormControl(1,Validators.required),
      gen_ris : new FormControl(1,Validators.required),
      ch_lu_dis : new FormControl(1,Validators.required),
      bal_diet : new FormControl(1,Validators.required),
      obese : new FormControl(1,Validators.required),
      smoke : new FormControl(1,Validators.required),
      pas_smo : new FormControl(1,Validators.required),
      chest_pain : new FormControl(1,Validators.required),
      cou_of_blo : new FormControl(1,Validators.required),
      fatigue : new FormControl(1,Validators.required),
      wei_Los : new FormControl(1,Validators.required),
      sho_of_br : new FormControl(1,Validators.required),
      whee : new FormControl(1,Validators.required),
      swa_dif : new FormControl(1,Validators.required),
      club_fina : new FormControl(1,Validators.required),
      fre_cold : new FormControl(1,Validators.required),
      dry_cou : new FormControl(1,Validators.required),
      snore : new FormControl(1,Validators.required)
    });

    this.thirdFormGroup = builder.group({
      gender : new FormControl(1,Validators.required),
      th_Pa : new FormControl(0,Validators.required),
      dys : new FormControl(0,Validators.required),
      fev : new FormControl(0,Validators.required),
      cou : new FormControl(0,Validators.required),
      hea : new FormControl(0,Validators.required),
      ta_di : new FormControl(0,Validators.required),
      ol_di : new FormControl(0,Validators.required),
      cor : new FormControl(0,Validators.required)
    })
   }

  ngOnInit(): void {
    this.dataShareService.login.subscribe(result => {
      this.userDetails = result;
    }); 
  }
  
  firstFormNext() : void{
    if(this.userDetails.loginId == "" ||  this.userDetails.loginId == null ||  this.userDetails.loginId == undefined){
      this.loginEmitter.emit("notLoggedIn");
      this.toastr.warning("You have not logged in. Please Log In to get detailed health report.", "Login Required" )
    }
    else{
      if(this.firstFormGroup.value.selSymp.length == 0){
        this.toastr.warning("Choose the symptoms from given list to proceed ahead.", "You have not chosen symptoms.")
      }
      else{
        if(this.firstFormGroup.value.selSymp.length > 17){
          this.toastr.warning("Only 17 symptoms are required.", "Please choose the relevant symptoms." )
        }
        else{
          
        }
      }
    }
  }

  secondFormNext() : void{
    if(this.userDetails.loginId == "" ||  this.userDetails.loginId == null ||  this.userDetails.loginId == undefined){
      this.loginEmitter.emit("notLoggedIn");
      this.toastr.warning("You have not logged in. Please Log In to get detailed health report.", "Login Required" )
    }
    else{
      if(this.firstFormGroup.value.selSymp.length == 0){
        this.toastr.warning("Choose the symptoms from given list to proceed ahead.", "You have not chosen symptoms." )
      }
      else{
        if(this.firstFormGroup.value.selSymp.length > 17){
          this.toastr.warning("Only 17 symptoms are required.", "Please choose the relevant symptoms." )
        }
        else{
          
        }
      }
    }
  }

  thirdFormNext() : void{
    if(this.userDetails.loginId == "" ||  this.userDetails.loginId == null ||  this.userDetails.loginId == undefined){
      this.loginEmitter.emit("notLoggedIn");
      this.toastr.warning("You have not logged in. Please Log In to get detailed health report.", "Login Required" )
    }
    else{
      if(this.firstFormGroup.value.selSymp.length == 0){
        this.toastr.warning("Choose the symptoms from given list to proceed ahead", "You have not chosen symptoms" )
      }
      else{
        if(this.firstFormGroup.value.selSymp.length > 17){
          this.toastr.warning("Only 17 symptoms are required.", "Please choose the relevant symptoms." )
        }
        else{
          
        }
      }
    }
  }

  proceed() : void{
    
    let symptoms : string[] = ["None","None","None","None","None","None","None","None","None","None","None","None","None","None","None","None","None"]
    this.secondFormGroup.value.gender = this.secondFormGroup.value.gender-1;
    for (let i = 0; i < this.firstFormGroup.value.selSymp.length; i++) {
      symptoms[i] = this.firstFormGroup.value.selSymp[i].Symp
    }
    
    let allFormValues : any = {firstForm : this.firstFormGroup.value.selSymp,
                               secondForm : this.secondFormGroup.value,
                               thirdForm : this.thirdFormGroup.value,
                               symptoms : symptoms,
                               loginId : this.userDetails.loginId}; 
    
    if(this.userDetails.loginId != "" &&  this.userDetails.loginId != null &&  this.userDetails.loginId != undefined){
      if(this.firstFormGroup.value.selSymp.length == 0){
        this.toastr.warning("Choose the symptoms from given list in first step to proceed ahead.", "You have not chosen symptoms." )
      }
      else{
        if(this.firstFormGroup.value.selSymp.length > 17){
          this.toastr.warning("You have chosen " + this.firstFormGroup.value.selSymp.length + " symptoms.", "Only 17 symptoms are required." )
        }
        else{
          this.spin = true;
          this.showPre = false;
          this.showReport = false;
          this.completed = false;
          this.landingService.dccPred(allFormValues).subscribe( data => {
            this.spin = false;
            this.completed = true;
            this.dataSource.data = data;
            this.result[0].res = data[0].dis;
            this.result[1].res = data[0].can;
            this.result[2].res = data[0].cov;
            this.result[3].res = data[0].dt;
          })
        }
      }
    }
    else{
      this.loginEmitter.emit("notLoggedIn");
      this.toastr.warning("You have not logged in. Please Log In to get detailed health report.", "Login Required" )
    }
  }

  download() : void{
    const doc = new jsPDF();
    autoTable(doc, { html: '#reportTable' }) 
    doc.save('report' + '.pdf');
  } 

  prevReports() : void{
    if(this.userDetails.loginId == "" ||  this.userDetails.loginId == null ||  this.userDetails.loginId == undefined){
      this.loginEmitter.emit("notLoggedIn");
      this.toastr.warning("You have not logged in. Please Log In to get previous health reports.", "Login Required" )
    }
    else{
      this.landingService.prevReports(this.userDetails.loginId).subscribe( data => {
        if(data.length != 0){
          console.log(data);
          this.completed = false;
          this.showPre = true;
          this.showReport = false;
          this.reports = data;
        }
        else{
          this.completed = false;
          this.showPre = false;
          this.showReport = false;
          this.toastr.error("Click Proceed to generate detailed health report", "No Previous Records Found")
        }
    })
    }  
  }

  fetchRep(i : number ) : void{
    this.showReport = true;
    this.completed = false;
    this.dataSource1.data = this.reports[i]
  }

  dowPrev() : void{
    const doc = new jsPDF();
    autoTable(doc, { html: '#preptbl' }) 
    //this.repnum = this.repnum + 1
    doc.save('report' + String(Number(this.repnum + 1)) + '.pdf');
  } 
}
