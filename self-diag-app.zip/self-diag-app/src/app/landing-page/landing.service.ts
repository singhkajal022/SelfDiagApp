import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LandingService {

  disurl : string = "http://127.0.0.1:5000/dis";
  canurl : string = "http://127.0.0.1:5000/can";
  covurl : string = "http://127.0.0.1:5000/cov";
  dccurl : string = "http://127.0.0.1:5000/dcc";
  preurl : string = "http://127.0.0.1:5000/pre"

  constructor(private http : HttpClient) { 

  }

  disePred(firstFormGroup : any) :  Observable<any> {
    return this.http.post<any[]>(this.disurl , firstFormGroup);
  }

  canPred(secondFormGroup : any) : Observable<any> {
    return this.http.post<any[]>(this.canurl , secondFormGroup);
  }

  covPred(thirdFormGroup : any) : Observable<any> {
    return this.http.post<any[]>(this.covurl , thirdFormGroup);
  }

  dccPred(allFormGroup: any) : Observable<any> {
    return this.http.post<any[]>(this.dccurl, allFormGroup)
  }

  prevReports(loginId : string) : Observable<any> {
    return this.http.post<any[]>(this.preurl, loginId)
  }


}
