import { Component, OnInit, Output, EventEmitter, Inject, ViewChild } from '@angular/core';
import { MatAccordion } from '@angular/material/expansion';
import { DataShareService } from '../data-share.service';


@Component({
  selector: 'app-symptoms',
  templateUrl: './symptoms.component.html',
  styleUrls: ['./symptoms.component.css']
})
export class SymptomsComponent implements OnInit {
  @Output() homeEmitter = new EventEmitter<any>();
  homevisi : any = {login : false,
                    landing : true,
                    symps : false
                  };
  panelOpenState : boolean = false;
  fsydecocau : any [] = [];
  ssydecocau : any [] = [];

  constructor( private dataShareService : DataShareService) { }

  ngOnInit(): void {
    this.dataShareService.sendSymp.subscribe(result => {
      this.fsydecocau = result.fsydecocau;
      this.ssydecocau = result.ssydecocau;
      
    });
  }

  home() : void{
    this.homeEmitter.emit(this.homevisi);
  }

}
