from flask import Flask, jsonify, request, render_template, flash;
from flask_cors import CORS, cross_origin;
from flask_sqlalchemy import SQLAlchemy
import json
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.optimizers import Adam
from sklearn.preprocessing import LabelEncoder
from sklearn.svm import SVC
from sklearn.metrics import f1_score, accuracy_score, confusion_matrix, classification_report
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import psycopg2
from sklearn.naive_bayes import GaussianNB

Comorbid = ['Chronic cholestasis', 'Hepatitis A', 'Hypoglycemia', 'Diabetes', 'Hypertension', 
            'Chicken pox', 'AIDS', 'Paralysis (brain hemorrhage)', 'Typhoid', 'Hepatitis B', 
            'Fungal infection', 'Hepatitis C', 'Bronchial Asthma', 'Alcoholic hepatitis', 
            'Jaundice', 'Dengue', 'Hepatitis D', 'Heart attack', 'Pneumonia', 'Tuberculosis']

Non_com = ['Drug Reaction', 'Malaria', 'Allergy', 'Hypothyroidism', 'Psoriasis', 'GERD',
           'Osteoarthritis', '(vertigo) Paroxysmal Positional Vertigo', 'Acne', 'Impetigo', 
           'Peptic ulcer disease', 'Dimorphic hemorrhoids(piles)', 'Common Cold', 
           'Cervical spondylosis', 'Hyperthyroidism', 'Urinary tract infection', 
           'Varicose veins', 'Migraine', 'Hepatitis E', 'Arthritis', 'Gastroenteritis']

def predDisease(disDetails):
    #disDetails = json.loads(request.data.decode('utf-8'))
    #print("*******************************************************************************************")
    print(disDetails)
    
    patdf = pd.read_csv("dataset.csv")
    sevdf = pd.read_csv("Symptom-severity.csv")
    symdf = pd.read_csv("symp_desc_prec.csv")
    
    patdf.isna().sum()
    patdf.isnull().sum()
    cols = patdf.columns
    data = patdf.values.flatten()
    s = pd.Series(data)
    s = s.str.strip()
    s = s.values.reshape(patdf.shape)
    patdf = pd.DataFrame(s, columns=patdf.columns)
    patdf = patdf.fillna('0')
    patdf = patdf.replace('dischromic _patches', 'dischromic_patches')
    patdf = patdf.replace('spotting_ urination','spotting_urination')
    patdf = patdf.replace('foul_smell_of urine','foul_smell_ofurine')
    
    ind = [i for i in range(len(patdf))]
    symptoms = sevdf['Symptom'].unique()
    symptoms.shape
    symptoms = np.append(symptoms,'Disease')
    new_df = pd.DataFrame(columns = symptoms, index = ind)
    for i in range(len(ind)):
        row = patdf.values[i]
        new_row = [0 for l in range(len(symptoms))]
        for j in range(len(row)):
            symp = row [j]
            for k,sym in enumerate(symptoms):            
                if symp == sym:
                    new_row[k]=sevdf[sevdf['Symptom']==symp]['weight'].values[0]                
        new_row[-1]=row[0]
        new_df.loc[i]=new_row
    new_df    
    data = new_df.iloc[:,0:-1].values
    labels = new_df.iloc[:,-1].values
    data=np.asarray(data).astype(np.float32)
    x_train, x_test, y_train, y_test = train_test_split(data, labels, shuffle=True, train_size = 0.60)
    one = OneHotEncoder(sparse=False)
    y_train = y_train.reshape(y_train.shape[0],1)
    y_test = y_test.reshape(y_test.shape[0],1)
    one.fit(y_train)
    Y_train = one.transform(y_train)
    Y_test = one.transform(y_test)
    net = Sequential()
    net.add(Dense(20, activation='sigmoid', input_shape = x_train.shape[1:]))
    net.add(Dense(41, activation='softmax'))
    opt = Adam(lr=0.001)
    net.compile(
        loss='categorical_crossentropy', 
        optimizer=opt, 
        metrics=['accuracy'])
    history = net.fit(x_train, Y_train,
                        validation_data=(x_test, Y_test),
                        epochs = 50,
                        batch_size=32) 
    gnb = GaussianNB()
    gnb.fit(x_train, y_train)
    preds = gnb.predict(x_test)
    print('Accuracy:', accuracy_score(y_test,preds))
    print('F1 Score:',f1_score(y_test,preds,average='macro'))
    diseases = new_df.iloc[:,-1].values
    symptom = []
    n = 0
    for i in disDetails:
        #print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
        print(i)
        symptom.append(i.get("Symp"))
        n = n + 1
    symptoms = sevdf['Symptom'].unique()
    samp_row = [0 for i in range(len(symptoms))]
    for i in range(len(symptom)):
        symp = symptom[i]
        for j,temp in enumerate(symptoms):
            if symp == temp:
                samp_row[j]=sevdf[sevdf['Symptom']==symp]['weight'].values[0]           
    tdf=np.array(samp_row).reshape(1, -1) 
    pred2 = gnb.predict(tdf)
    probs = gnb.predict_proba(tdf)
    net_pred = net.predict(np.array(tdf))
    predicted_val = one.inverse_transform(net_pred)
    print("Symptoms Entered:")
    for i in range(n):
        print("Symptom {}: {}".format(i+1,symptom[i]))
    
    print("\nPredicted Disease\n\nGaussian Naive Bayes: ", pred2[0])
    print("\nNeural Network:", predicted_val[0][0])
    diseases = new_df.iloc[:,-1].values
    diseases = np.unique(diseases)
    pred_probs = []
    for i in range(len(net_pred[0])):
        dict_new = {'Disease':diseases[i],'Prob':net_pred[0][i]}
        pred_probs.append(dict_new)
    sorted(pred_probs, key = lambda i: i['Prob'],reverse=True)
    return predicted_val[0][0]

def predCancer(canDetails):
    #canDetails = json.loads(request.data.decode('utf-8'))
    candf = pd.read_csv("cancer-patient-data.csv")
    canX = candf.iloc[:,1:-1].values
    canY = candf.iloc[:,-1].values
    canXTr, canXTe, canYTr, canYTe = train_test_split(canX, canY, shuffle=True, train_size = 0.60)
    canYTr = canYTr.reshape(canYTr.shape[0],1)
    canYTe = canYTe.reshape(canYTe.shape[0],1)
    enc = OneHotEncoder(sparse=False)
    enc.fit(canYTr)
    CanYTr = enc.transform(canYTr)
    CanYTe = enc.transform(canYTe)
    model = Sequential()
    model.add(Dense(20, activation='sigmoid', input_shape = canXTr.shape[1:]))
    model.add(Dense(3, activation='softmax'))
    opt = Adam(lr=0.001)
    model.compile(
         loss='categorical_crossentropy', 
         optimizer=opt, 
         metrics=['accuracy'])
    history = model.fit(canXTr, CanYTr,
                    validation_data=(canXTe, CanYTe),
                    epochs = 50,
                    batch_size=32) 
    lab = LabelEncoder()
    lab.fit(canY)
    canY = lab.transform(canY)
    candf['Level'] = canY
    candf
    svm = SVC()
    svm.fit(canXTr, canYTr)
    canYPred = svm.predict(canXTe)
    print('Accuracy:', accuracy_score(canYTe,canYPred))
    print('F1 Score:',f1_score(canYTe,canYPred,average='macro'))
    feats = candf.columns[1:-1]
    x_sam = []
    x_sam.append(canDetails.get("age"))
    x_sam.append(canDetails.get("gender"))
    x_sam.append(canDetails.get("air_poll"))
    x_sam.append(canDetails.get("alc_use"))
    x_sam.append(canDetails.get("dust_all"))
    x_sam.append(canDetails.get("occ_Haz"))
    x_sam.append(canDetails.get("gen_ris"))
    x_sam.append(canDetails.get("ch_lu_dis"))
    x_sam.append(canDetails.get("bal_diet"))
    x_sam.append(canDetails.get("obese"))
    x_sam.append(canDetails.get("smoke"))
    x_sam.append(canDetails.get("pas_smo"))
    x_sam.append(canDetails.get("chest_pain"))
    x_sam.append(canDetails.get("cou_of_blo"))
    x_sam.append(canDetails.get("fatigue"))
    x_sam.append(canDetails.get("wei_Los"))
    x_sam.append(canDetails.get("sho_of_br"))
    x_sam.append(canDetails.get("whee"))
    x_sam.append(canDetails.get("swa_dif"))
    x_sam.append(canDetails.get("club_fina"))
    x_sam.append(canDetails.get("fre_cold"))
    x_sam.append(canDetails.get("dry_cou"))
    x_sam.append(canDetails.get("snore"))
    samp = np.array(x_sam).reshape(1, -1)
    print(samp)
    pred = svm.predict(samp)
    nn_pred = model.predict(samp)
    if pred == 0:
        pred = 'High'
    elif pred == 1:
        pred = 'Low'
    else:
        pred = 'Medium'
    print(nn_pred)
    print("\nPossibility of cancer:\nSVM:", pred)
    nn = np.argmax(nn_pred[0])
    if nn == 0:
        nn = 'High'
    elif nn == 1:
        nn = 'Low'
    else:
        nn = 'Medium'
    print("Neural Net:",nn)
    print('Probs:\nLow:{}\nMedium:{}\nHigh:{}'.format(nn_pred[0][1],nn_pred[0][2],nn_pred[0][0]))
    rfc = RandomForestClassifier()
    rfc.fit(canXTr,canYTr)
    pred = rfc.predict(samp)
    prob = rfc.predict_proba(samp)
    print('\nRandom Forest Classifier:', pred[0])
    print('Probs:\nLow:{}\nMedium:{}\nHigh:{}'.format(prob[0][1],prob[0][2],prob[0][0]))
    return nn

def predCovid(covDetails):
    #covDetails = json.loads(request.data.decode('utf-8'))
    
    covdf = pd.read_csv("both_test_balanced.csv")
    CovX = covdf.iloc[:,:-2].values
    CovY = covdf.iloc[:,-1].values

    covx_train, covx_test, covy_train, covy_test = train_test_split(CovX, CovY, shuffle=True, train_size = 0.60)
    print(covx_train.shape, covx_test.shape, covy_train.shape, covy_test.shape)
    covy_train = covy_train.reshape(covy_train.shape[0],1)
    covy_test = covy_test.reshape(covy_test.shape[0],1)
    enc = OneHotEncoder(sparse=False)
    enc.fit(covy_train)
    COVY_train = enc.transform(covy_train)
    COVY_test = enc.transform(covy_test)
    model = Sequential()
    model.add(Dense(20, activation='sigmoid', input_shape = covx_train.shape[1:]))
    model.add(Dense(2, activation='softmax'))
    opt = Adam(lr=0.001)
    model.compile(
        loss='categorical_crossentropy', 
        optimizer=opt, 
        metrics=['accuracy'])
    
    history = model.fit(covx_train, COVY_train,
                    validation_data=(covx_test, COVY_test),
                    epochs = 50,
                    batch_size=32) 
    svm = SVC()
    svm.fit(covx_train, covy_train)
    covy_pred = svm.predict(covx_test)
    print('Accuracy:', accuracy_score(covy_test,covy_pred))
    print('F1 Score:',f1_score(covy_test,covy_pred,average='macro'))
    print(classification_report(covy_test,covy_pred))
    
    cols = covdf.columns[:-2]
    sample = []
    sample.append(covDetails.get("th_Pa"))
    sample.append(covDetails.get("dys"))
    sample.append(covDetails.get("fev"))
    sample.append(covDetails.get("cou"))
    sample.append(covDetails.get("hea"))
    sample.append(covDetails.get("ta_di"))
    sample.append(covDetails.get("ol_di"))
    sample.append(covDetails.get("cor")) 
    sample.append(covDetails.get("gender")-1)
    sample = np.array(sample).reshape(1,-1)
    nn = model.predict(sample)
    predicted = svm.predict(sample)
    if predicted == 0:
        predicted = 'Negative'
    else:
        predicted = 'Positive'
    if np.argmax(nn) == 0:
        p = 'Negative'
    else:
        p = 'Positive'
    print('\nPredicted COVID report', predicted)
    print("Neural Network:", p)
    print("Probs:",nn)
    return p

def get_trust(cancer, disease, covid):
    DT = 5
    T = 0
    T1 = 0
    T2 = 0
    T3 = 0
    if disease in list(Comorbid):
        T1 = 1
    elif disease in list(Non_com): 
        T1 = 0

    if cancer == 'Low':    
        T2 = 0
    elif cancer == 'Medium':
        T2 = 1
    else:
        T2 = 2

    if covid == 'Positive':
        T3 = 1
    else:
        T3 = 0

    T = T1+T2+T3

    if (T == 0) or (T ==1 and T1 == 0 and T3 == 0):
        DT = 2
    elif (T == 1 and T1 == 1 and T3 == 0 ) or (T == 1 and T1 == 0 and T3 == 1) or (T == 1 and T1 == 0 and T2 == 1) or (T == 2 and T1 == 0 and T3 == 0) or (T == 2 and T1 == 1 and T3 == 0):
        DT = 1
    elif (T == 2 and T1 == 1 and T3 == 1) or T>2:
        DT = 0
        
    return DT
"""   
@app.route("/dis", methods=['POST'])
@cross_origin()
def predDis():
    disDetails = json.loads(request.data.decode('utf-8'))
    print(disDetails)
    
    patdf = pd.read_csv("dataset.csv")
    sevdf = pd.read_csv("Symptom-severity.csv")
    symdf = pd.read_csv("symp_desc_prec.csv")
    
    patdf.isna().sum()
    patdf.isnull().sum()
    cols = patdf.columns
    data = patdf.values.flatten()
    s = pd.Series(data)
    s = s.str.strip()
    s = s.values.reshape(patdf.shape)
    patdf = pd.DataFrame(s, columns=patdf.columns)
    patdf = patdf.fillna('0')
    patdf = patdf.replace('dischromic _patches', 'dischromic_patches')
    patdf = patdf.replace('spotting_ urination','spotting_urination')
    patdf = patdf.replace('foul_smell_of urine','foul_smell_ofurine')
    
    ind = [i for i in range(len(patdf))]
    symptoms = sevdf['Symptom'].unique()
    symptoms.shape
    symptoms = np.append(symptoms,'Disease')
    new_df = pd.DataFrame(columns = symptoms, index = ind)
    for i in range(len(ind)):
        row = patdf.values[i]
        new_row = [0 for l in range(len(symptoms))]
        for j in range(len(row)):
            symp = row [j]
            for k,sym in enumerate(symptoms):            
                if symp == sym:
                    new_row[k]=sevdf[sevdf['Symptom']==symp]['weight'].values[0]                
        new_row[-1]=row[0]
        new_df.loc[i]=new_row
    new_df    
    data = new_df.iloc[:,0:-1].values
    labels = new_df.iloc[:,-1].values
    data=np.asarray(data).astype(np.float32)
    x_train, x_test, y_train, y_test = train_test_split(data, labels, shuffle=True, train_size = 0.60)
    one = OneHotEncoder(sparse=False)
    y_train = y_train.reshape(y_train.shape[0],1)
    y_test = y_test.reshape(y_test.shape[0],1)
    one.fit(y_train)
    Y_train = one.transform(y_train)
    Y_test = one.transform(y_test)
    net = Sequential()
    net.add(Dense(20, activation='sigmoid', input_shape = x_train.shape[1:]))
    net.add(Dense(41, activation='softmax'))
    opt = Adam(lr=0.001)
    net.compile(
        loss='categorical_crossentropy', 
        optimizer=opt, 
        metrics=['accuracy'])
    history = net.fit(x_train, Y_train,
                        validation_data=(x_test, Y_test),
                        epochs = 50,
                        batch_size=32) 
    gnb = GaussianNB()
    gnb.fit(x_train, y_train)
    preds = gnb.predict(x_test)
    print('Accuracy:', accuracy_score(y_test,preds))
    print('F1 Score:',f1_score(y_test,preds,average='macro'))
    diseases = new_df.iloc[:,-1].values
    symptom = []
    n = 0
    for i in disDetails:
        symptom.append(i.get("Symp"))
        n = n + 1
    symptoms = sevdf['Symptom'].unique()
    samp_row = [0 for i in range(len(symptoms))]
    for i in range(len(symptom)):
        symp = symptom[i]
        for j,temp in enumerate(symptoms):
            if symp == temp:
                samp_row[j]=sevdf[sevdf['Symptom']==symp]['weight'].values[0]           
    tdf=np.array(samp_row).reshape(1, -1) 
    pred2 = gnb.predict(tdf)
    probs = gnb.predict_proba(tdf)
    net_pred = net.predict(np.array(tdf))
    predicted_val = one.inverse_transform(net_pred)
    print("Symptoms Entered:")
    for i in range(n):
        print("Symptom {}: {}".format(i+1,symptom[i]))
    
    print("\nPredicted Disease\n\nGaussian Naive Bayes: ", pred2[0])
    print("\nNeural Network:", predicted_val[0][0])
    diseases = new_df.iloc[:,-1].values
    diseases = np.unique(diseases)
    pred_probs = []
    for i in range(len(net_pred[0])):
        dict_new = {'Disease':diseases[i],'Prob':net_pred[0][i]}
        pred_probs.append(dict_new)
    print(sorted(pred_probs, key = lambda i: i['Prob'],reverse=True))
    return jsonify(predicted_val[0][0])
 
@app.route("/can", methods=['POST'])
@cross_origin()
def predCan():     
     canDetails = json.loads(request.data.decode('utf-8'))
     candf = pd.read_csv("cancer-patient-data.csv")
     canX = candf.iloc[:,1:-1].values
     canY = candf.iloc[:,-1].values
     canXTr, canXTe, canYTr, canYTe = train_test_split(canX, canY, shuffle=True, train_size = 0.60)
     canYTr = canYTr.reshape(canYTr.shape[0],1)
     canYTe = canYTe.reshape(canYTe.shape[0],1)
     enc = OneHotEncoder(sparse=False)
     enc.fit(canYTr)
     CanYTr = enc.transform(canYTr)
     CanYTe = enc.transform(canYTe)
     model = Sequential()
     model.add(Dense(20, activation='sigmoid', input_shape = canXTr.shape[1:]))
     model.add(Dense(3, activation='softmax'))
     opt = Adam(lr=0.001)
     model.compile(
         loss='categorical_crossentropy', 
         optimizer=opt, 
         metrics=['accuracy'])
     history = model.fit(canXTr, CanYTr,
                    validation_data=(canXTe, CanYTe),
                    epochs = 50,
                    batch_size=32) 
     lab = LabelEncoder()
     lab.fit(canY)
     canY = lab.transform(canY)
     candf['Level'] = canY
     candf
     svm = SVC()
     svm.fit(canXTr, canYTr)
     canYPred = svm.predict(canXTe)
     print('Accuracy:', accuracy_score(canYTe,canYPred))
     print('F1 Score:',f1_score(canYTe,canYPred,average='macro'))
     feats = candf.columns[1:-1]
     x_sam = []
     x_sam.append(canDetails.get("age"))
     x_sam.append(canDetails.get("gender"))
     x_sam.append(canDetails.get("air_poll"))
     x_sam.append(canDetails.get("alc_use"))
     x_sam.append(canDetails.get("dust_all"))
     x_sam.append(canDetails.get("occ_Haz"))
     x_sam.append(canDetails.get("gen_ris"))
     x_sam.append(canDetails.get("ch_lu_dis"))
     x_sam.append(canDetails.get("bal_diet"))
     x_sam.append(canDetails.get("obese"))
     x_sam.append(canDetails.get("smoke"))
     x_sam.append(canDetails.get("pas_smo"))
     x_sam.append(canDetails.get("chest_pain"))
     x_sam.append(canDetails.get("cou_of_blo"))
     x_sam.append(canDetails.get("fatigue"))
     x_sam.append(canDetails.get("wei_Los"))
     x_sam.append(canDetails.get("sho_of_br"))
     x_sam.append(canDetails.get("whee"))
     x_sam.append(canDetails.get("swa_dif"))
     x_sam.append(canDetails.get("club_fina"))
     x_sam.append(canDetails.get("fre_cold"))
     x_sam.append(canDetails.get("dry_cou"))
     x_sam.append(canDetails.get("snore"))
     samp = np.array(x_sam).reshape(1, -1)
     pred = svm.predict(samp)
     nn_pred = model.predict(samp)
     if pred == 0:
        pred = 'High'
     elif pred == 1:
        pred = 'Low'
     else:
        pred = 'Medium'
     print(nn_pred)
     print("\nPossibility of cancer:\nSVM:", pred)
     nn = np.argmax(nn_pred[0])
     if nn == 0:
         nn = 'High'
     elif nn == 1:
         nn = 'Low'
     else:
         nn = 'Medium'
     print("Neural Net:",nn)
     print('Probs:\nLow:{}\nMedium:{}\nHigh:{}'.format(nn_pred[0][1],nn_pred[0][2],nn_pred[0][0]))
     rfc = RandomForestClassifier()
     rfc.fit(canXTr,canYTr)
     pred = rfc.predict(samp)
     prob = rfc.predict_proba(samp)
     print('\nRandom Forest Classifier:', pred[0])
     print('Probs:\nLow:{}\nMedium:{}\nHigh:{}'.format(prob[0][1],prob[0][2],prob[0][0]))
     
     
     cancer = Cancer(canDetails.get("loginId"), canDetails.get("age"), canDetails.get("gender"), canDetails.get("air_poll"), canDetails.get("alc_use"), canDetails.get("dust_all"), canDetails.get("occ_Haz"), canDetails.get("gen_ris"), canDetails.get("ch_lu_dis"), canDetails.get("bal_diet"), canDetails.get("obese"), canDetails.get("smoke"), canDetails.get("pas_smo"), canDetails.get("chest_pain"), canDetails.get("cou_of_blo"), canDetails.get("fatigue"), canDetails.get("wei_Los"), canDetails.get("sho_of_br"), canDetails.get("whee"), canDetails.get("swa_dif"), canDetails.get("club_fina"), canDetails.get("fre_cold"), canDetails.get("dry_cou"), canDetails.get("snore"),nn)
     db.session.add(cancer)
     db.session.commit()
     return jsonify(nn)
 

@app.route("/cov", methods=['POST'])
@cross_origin()
def predCov():
    covDetails = json.loads(request.data.decode('utf-8'))
    
    covdf = pd.read_csv("both_test_balanced.csv")
    CovX = covdf.iloc[:,:-2].values
    CovY = covdf.iloc[:,-1].values

    covx_train, covx_test, covy_train, covy_test = train_test_split(CovX, CovY, shuffle=True, train_size = 0.60)
    print(covx_train.shape, covx_test.shape, covy_train.shape, covy_test.shape)
    covy_train = covy_train.reshape(covy_train.shape[0],1)
    covy_test = covy_test.reshape(covy_test.shape[0],1)
    enc = OneHotEncoder(sparse=False)
    enc.fit(covy_train)
    COVY_train = enc.transform(covy_train)
    COVY_test = enc.transform(covy_test)
    model = Sequential()
    model.add(Dense(20, activation='sigmoid', input_shape = covx_train.shape[1:]))
    model.add(Dense(2, activation='softmax'))
    opt = Adam(lr=0.001)
    model.compile(
        loss='categorical_crossentropy', 
        optimizer=opt, 
        metrics=['accuracy'])
    
    history = model.fit(covx_train, COVY_train,
                    validation_data=(covx_test, COVY_test),
                    epochs = 50,
                    batch_size=32) 
    svm = SVC()
    svm.fit(covx_train, covy_train)
    covy_pred = svm.predict(covx_test)
    print('Accuracy:', accuracy_score(covy_test,covy_pred))
    print('F1 Score:',f1_score(covy_test,covy_pred,average='macro'))
    print(classification_report(covy_test,covy_pred))
    
    cols = covdf.columns[:-2]
    sample = []
    sample.append(covDetails.get("th_Pa"))
    sample.append(covDetails.get("dys"))
    sample.append(covDetails.get("fev"))
    sample.append(covDetails.get("cou"))
    sample.append(covDetails.get("hea"))
    sample.append(covDetails.get("ta_di"))
    sample.append(covDetails.get("ol_di"))
    sample.append(covDetails.get("cor")) 
    sample.append(covDetails.get("gender")-1)
    sample = np.array(sample).reshape(1,-1)
    nn = model.predict(sample)
    predicted = svm.predict(sample)
    if predicted == 0:
        predicted = 'Negative'
    else:
        predicted = 'Positive'
    if np.argmax(nn) == 0:
        p = 'Negative'
    else:
        p = 'Positive'
    print('\nPredicted COVID report', predicted)
    print("Neural Network:", p)
    print("Probs:",nn)
    #def __init__(self,         LoginId,                Throat_Pain,                Dyspnea,                Fever,                  Cough,              Headache,               Taste_Disorders,        Olfactory_Disorders,        Coryza,                 Gender,     Result):
    covid = Covid(covDetails.get("loginId"), covDetails.get("th_Pa"), covDetails.get("dys"), covDetails.get("fev"), covDetails.get("cou"), covDetails.get("hea"), covDetails.get("ta_di"), covDetails.get("ol_di"), covDetails.get("cor"), covDetails.get("gender")-1, p)
    db.session.add(covid)
    db.session.commit()
    return jsonify(p)

"""

'''
class Cancer(db.Model):
    __tablename__ = "Cancer_Patient"
    Patient_Id = db.Column(db.Integer, nullable=False, primary_key=True, autoincrement=True)
    LoginId = db.Column(db.String(255), nullable=False, primary_key=False)
    Age = db.Column(db.Integer, nullable=False, primary_key=False)
    Gender = db.Column(db.Integer, nullable=False, primary_key=False)
    Air_Pollution = db.Column(db.Integer, nullable=False, primary_key=False)
    Alcohol_use = db.Column(db.Integer, nullable=False, primary_key=False)
    Dust_Allergy = db.Column(db.Integer, nullable=False, primary_key=False)
    Occupational_Hazards = db.Column(db.Integer, nullable=False, primary_key=False)
    Genetic_Risk = db.Column(db.Integer, nullable=False, primary_key=False)
    Chronic_Lung_Disease = db.Column(db.Integer, nullable=False, primary_key=False)
    Balanced_Diet = db.Column(db.Integer, nullable=False, primary_key=False)
    Obesity = db.Column(db.Integer, nullable=False, primary_key=False)
    Smoking = db.Column(db.Integer, nullable=False, primary_key=False)
    Passive_Smoker = db.Column(db.Integer, nullable=False, primary_key=False)
    Chest_Pain = db.Column(db.Integer, nullable=False, primary_key=False)
    Coughing_of_Blood = db.Column(db.Integer, nullable=False, primary_key=False)
    Fatigue = db.Column(db.Integer, nullable=False, primary_key=False)
    Weight_Loss = db.Column(db.Integer, nullable=False, primary_key=False)
    Shortness_of_Breath = db.Column(db.Integer, nullable=False, primary_key=False)
    Wheezing = db.Column(db.Integer, nullable=False, primary_key=False)
    Swallowing_Difficulty = db.Column(db.Integer, nullable=False, primary_key=False)
    Clubbing_of_Finger_Nails = db.Column(db.Integer, nullable=False, primary_key=False)
    Frequent_Cold = db.Column(db.Integer, nullable=False, primary_key=False)
    Dry_Cough = db.Column(db.Integer, nullable=False, primary_key=False)
    Snoring = db.Column(db.Integer, nullable=False, primary_key=False)
    Level = db.Column(db.String(255), nullable=False, primary_key=False)
    
    def __init__(self, LoginId, Age, Gender, Air_Pollution, Alcohol_use, Dust_Allergy, Occupational_Hazards, Genetic_Risk, Chronic_Lung_Disease, Balanced_Diet, Obesity, Smoking, Passive_Smoker, Chest_Pain, Coughing_of_Blood, Fatigue, Weight_Loss, Shortness_of_Breath, Wheezing, Swallowing_Difficulty, Clubbing_of_Finger_Nails, Frequent_Cold, Dry_Cough, Snoring, Level):
        self.LoginId = LoginId
        self.Age = Age
        self.Gender = Gender
        self.Air_Pollution = Air_Pollution
        self.Alcohol_use = Alcohol_use
        self.Dust_Allergy = Dust_Allergy
        self.Occupational_Hazards = Occupational_Hazards
        self.Genetic_Risk = Genetic_Risk
        self.Chronic_Lung_Disease = Chronic_Lung_Disease
        self.Balanced_Diet = Balanced_Diet
        self.Obesity = Obesity
        self.Smoking = Smoking
        self.Passive_Smoker = Passive_Smoker
        self.Chest_Pain = Chest_Pain
        self.Coughing_of_Blood = Coughing_of_Blood
        self.Fatigue = Fatigue
        self.Weight_Loss = Weight_Loss
        self.Shortness_of_Breath = Shortness_of_Breath
        self.Wheezing = Wheezing
        self.Swallowing_Difficulty = Swallowing_Difficulty
        self.Clubbing_of_Finger_Nails = Clubbing_of_Finger_Nails
        self.Frequent_Cold = Frequent_Cold
        self.Dry_Cough = Dry_Cough
        self.Snoring = Snoring
        self.Level = Level
        
        
class Covid(db.Model):
    __tablename__ = "Covid_Patient"
    Patient_Id = db.Column(db.Integer, nullable=False, primary_key=True, autoincrement=True)
    LoginId = db.Column(db.String(255), nullable=False, primary_key=False)
    Throat_Pain = db.Column(db.Integer, nullable=False, primary_key=False)
    Dyspnea = db.Column(db.Integer, nullable=False, primary_key=False)
    Fever = db.Column(db.Integer, nullable=False, primary_key=False)
    Cough = db.Column(db.Integer, nullable=False, primary_key=False)
    Headache = db.Column(db.Integer, nullable=False, primary_key=False)
    Taste_Disorders = db.Column(db.Integer, nullable=False, primary_key=False)
    Olfactory_Disorders = db.Column(db.Integer, nullable=False, primary_key=False)
    Coryza = db.Column(db.Integer, nullable=False, primary_key=False)
    Gender = db.Column(db.Integer, nullable=False, primary_key=False)  
    Result = db.Column(db.String(255), nullable=False, primary_key=False)
    
    def __init__(self, LoginId, Throat_Pain, Dyspnea, Fever, Cough, Headache, Taste_Disorders, Olfactory_Disorders, Coryza, Gender, Result):
        self.LoginId = LoginId
        self.Throat_Pain = Throat_Pain
        self.Dyspnea = Dyspnea
        self.Fever = Fever
        self.Cough = Cough
        self.Headache = Headache
        self.Taste_Disorders = Taste_Disorders
        self.Olfactory_Disorders = Olfactory_Disorders
        self.Coryza = Coryza
        self.Gender = Gender
        self.Result = Result
''' 