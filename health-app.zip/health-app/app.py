from flask import Flask, jsonify, request;
from flask_cors import CORS, cross_origin;
from flask_sqlalchemy import SQLAlchemy
import json
import psycopg2
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.optimizers import Adam
from sklearn.preprocessing import LabelEncoder
from sklearn.svm import SVC
from sklearn.metrics import f1_score, accuracy_score, confusion_matrix, classification_report
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
import smtplib
from flask_mail import Mail, Message


app = Flask(__name__)
mail = Mail(app)

app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'yourId@gmail.com'
app.config['MAIL_PASSWORD'] = '*****'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)

CORS(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:1111@127.0.0.1:5432/SelfDiagHealth'
db = SQLAlchemy(app)


Comorbid = ['Chronic cholestasis', 'Hepatitis A', 'Hypoglycemia', 'Diabetes', 'Hypertension', 
            'Chicken pox', 'AIDS', 'Paralysis (brain hemorrhage)', 'Typhoid', 'Hepatitis B', 
            'Fungal infection', 'Hepatitis C', 'Bronchial Asthma', 'Alcoholic hepatitis', 
            'Jaundice', 'Dengue', 'Hepatitis D', 'Heart attack', 'Pneumonia', 'Tuberculosis']

Non_com = ['Drug Reaction', 'Malaria', 'Allergy', 'Hypothyroidism', 'Psoriasis', 'GERD',
           'Osteoarthritis', '(vertigo) Paroxysmal Positional Vertigo', 'Acne', 'Impetigo', 
           'Peptic ulcer disease', 'Dimorphic hemorrhoids(piles)', 'Common Cold', 
           'Cervical spondylosis', 'Hyperthyroidism', 'Urinary tract infection', 
           'Varicose veins', 'Migraine', 'Hepatitis E', 'Arthritis', 'Gastroenteritis']


class Profile(db.Model):
    __tablename__ = "Patient"
    LoginId = db.Column(db.String(255), primary_key=True, nullable=False)
    Passw = db.Column(db.String(255), primary_key=False, nullable=False)
    First_Name = db.Column(db.String(255), primary_key=False, nullable=False)
    Last_Name = db.Column(db.String(255), primary_key=False, nullable=False)
    Gender = db.Column(db.String(255), primary_key=False, nullable=False)
    DOB = db.Column(db.String(255), primary_key=False, nullable=False)
    Age = db.Column(db.Integer, primary_key=False, nullable=False)
    Address = db.Column(db.String(255), primary_key=False, nullable=False)
    EmailId = db.Column(db.String(255), primary_key=False, nullable=False)
    Sec_Que1 = db.Column(db.String(255), primary_key=False, nullable=False)
    Sec_Que2 = db.Column(db.String(255), primary_key=False, nullable=False)
    Sec_Ans1 = db.Column(db.String(255), primary_key=False, nullable=False)
    Sec_Ans2 = db.Column(db.String(255), primary_key=False, nullable=False)

    def __init__(self, LoginId, Passw, First_Name, Last_Name, Gender, DOB, Age, Address, EmailId, Sec_Que1, Sec_Que2, Sec_Ans1, Sec_Ans2):
        self.LoginId = LoginId
        self.Passw = Passw
        self.First_Name = First_Name
        self.Last_Name = Last_Name
        self.Gender = Gender
        self.DOB = DOB
        self.Age = Age
        self.Address = Address
        self.EmailId = EmailId
        self.Sec_Que1 = Sec_Que1
        self.Sec_Que2 = Sec_Que2
        self.Sec_Ans1 = Sec_Ans1
        self.Sec_Ans2 = Sec_Ans2

       
        
class DisCanCov(db.Model):
    __tablename__ = "Dcc_Patient"
    Patient_Id = db.Column(db.Integer, nullable=False, primary_key=True, autoincrement=True)
    LoginId = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_1 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_2 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_3 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_4 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_5 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_6 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_7 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_8 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_9 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_10 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_11 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_12 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_13 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_14 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_15 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_16 = db.Column(db.String(255), nullable=False, primary_key=False)
    Symptom_17 = db.Column(db.String(255), nullable=False, primary_key=False)
    Disease = db.Column(db.String(255), nullable=False, primary_key=False)
    Age = db.Column(db.Integer, nullable=False, primary_key=False)
    Gender = db.Column(db.Integer, nullable=False, primary_key=False)
    Air_Pollution = db.Column(db.Integer, nullable=False, primary_key=False)
    Alcohol_use = db.Column(db.Integer, nullable=False, primary_key=False)
    Dust_Allergy = db.Column(db.Integer, nullable=False, primary_key=False)
    Occupational_Hazards = db.Column(db.Integer, nullable=False, primary_key=False)
    Genetic_Risk = db.Column(db.Integer, nullable=False, primary_key=False)
    Chronic_Lung_Disease = db.Column(db.Integer, nullable=False, primary_key=False)
    Balanced_Diet = db.Column(db.Integer, nullable=False, primary_key=False)
    Obesity = db.Column(db.Integer, nullable=False, primary_key=False)
    Smoking = db.Column(db.Integer, nullable=False, primary_key=False)
    Passive_Smoker = db.Column(db.Integer, nullable=False, primary_key=False)
    Chest_Pain = db.Column(db.Integer, nullable=False, primary_key=False)
    Coughing_of_Blood = db.Column(db.Integer, nullable=False, primary_key=False)
    Fatigue = db.Column(db.Integer, nullable=False, primary_key=False)
    Weight_Loss = db.Column(db.Integer, nullable=False, primary_key=False)
    Shortness_of_Breath = db.Column(db.Integer, nullable=False, primary_key=False)
    Wheezing = db.Column(db.Integer, nullable=False, primary_key=False)
    Swallowing_Difficulty = db.Column(db.Integer, nullable=False, primary_key=False)
    Clubbing_of_Finger_Nails = db.Column(db.Integer, nullable=False, primary_key=False)
    Frequent_Cold = db.Column(db.Integer, nullable=False, primary_key=False)
    Dry_Cough = db.Column(db.Integer, nullable=False, primary_key=False)
    Snoring = db.Column(db.Integer, nullable=False, primary_key=False)
    Level = db.Column(db.String(255), nullable=False, primary_key=False)
    Throat_Pain = db.Column(db.Integer, nullable=False, primary_key=False)
    Dyspnea = db.Column(db.Integer, nullable=False, primary_key=False)
    Fever = db.Column(db.Integer, nullable=False, primary_key=False)
    Cough = db.Column(db.Integer, nullable=False, primary_key=False)
    Headache = db.Column(db.Integer, nullable=False, primary_key=False)
    Taste_Disorders = db.Column(db.Integer, nullable=False, primary_key=False)
    Olfactory_Disorders = db.Column(db.Integer, nullable=False, primary_key=False)
    Coryza = db.Column(db.Integer, nullable=False, primary_key=False) 
    Result = db.Column(db.String(255), nullable=False, primary_key=False)
    Trust_Level = db.Column(db.Integer, nullable=False, primary_key=False)
    
    
    def __init__(self, LoginId, Symptom_1, Symptom_2, Symptom_3, Symptom_4, Symptom_5, Symptom_6, Symptom_7, Symptom_8, Symptom_9, Symptom_10, Symptom_11, Symptom_12, Symptom_13, Symptom_14, Symptom_15, Symptom_16, Symptom_17, Disease, Age, Gender, Air_Pollution, Alcohol_use, Dust_Allergy, Occupational_Hazards, Genetic_Risk, Chronic_Lung_Disease, Balanced_Diet, Obesity, Smoking, Passive_Smoker, Chest_Pain, Coughing_of_Blood, Fatigue, Weight_Loss, Shortness_of_Breath, Wheezing, Swallowing_Difficulty, Clubbing_of_Finger_Nails, Frequent_Cold, Dry_Cough, Snoring, Level, Throat_Pain, Dyspnea, Fever, Cough, Headache, Taste_Disorders, Olfactory_Disorders, Coryza, Result, Trust_Level):        
        self.LoginId = LoginId
        self.Symptom_1 = Symptom_1
        self.Symptom_2 = Symptom_2
        self.Symptom_3 = Symptom_3
        self.Symptom_4 = Symptom_4
        self.Symptom_5 = Symptom_5
        self.Symptom_6 = Symptom_6
        self.Symptom_7 = Symptom_7
        self.Symptom_8 = Symptom_8
        self.Symptom_9 = Symptom_9
        self.Symptom_10 = Symptom_10
        self.Symptom_11 = Symptom_11
        self.Symptom_12 = Symptom_12
        self.Symptom_13 = Symptom_13
        self.Symptom_14 = Symptom_14
        self.Symptom_15 = Symptom_15
        self.Symptom_16 = Symptom_16
        self.Symptom_17 = Symptom_17
        self.Disease = Disease
        self.Age = Age
        self.Gender = Gender
        self.Air_Pollution = Air_Pollution
        self.Alcohol_use = Alcohol_use
        self.Dust_Allergy = Dust_Allergy
        self.Occupational_Hazards = Occupational_Hazards
        self.Genetic_Risk = Genetic_Risk
        self.Chronic_Lung_Disease = Chronic_Lung_Disease
        self.Balanced_Diet = Balanced_Diet
        self.Obesity = Obesity
        self.Smoking = Smoking
        self.Passive_Smoker = Passive_Smoker
        self.Chest_Pain = Chest_Pain
        self.Coughing_of_Blood = Coughing_of_Blood
        self.Fatigue = Fatigue
        self.Weight_Loss = Weight_Loss
        self.Shortness_of_Breath = Shortness_of_Breath
        self.Wheezing = Wheezing
        self.Swallowing_Difficulty = Swallowing_Difficulty
        self.Clubbing_of_Finger_Nails = Clubbing_of_Finger_Nails
        self.Frequent_Cold = Frequent_Cold
        self.Dry_Cough = Dry_Cough
        self.Snoring = Snoring
        self.Level = Level
        self.Throat_Pain = Throat_Pain
        self.Dyspnea = Dyspnea
        self.Fever = Fever
        self.Cough = Cough
        self.Headache = Headache
        self.Taste_Disorders = Taste_Disorders
        self.Olfactory_Disorders = Olfactory_Disorders
        self.Coryza = Coryza
        self.Result = Result
        self.Trust_Level = Trust_Level

        
def index():
    return "Welcome to CodezUp"


def predDisease(disDetails):
    print(disDetails)
    patdf = pd.read_csv("dataset.csv")
    sevdf = pd.read_csv("Symptom-severity.csv")
    symdf = pd.read_csv("symp_desc_prec.csv")
    patdf.isna().sum()
    patdf.isnull().sum()
    cols = patdf.columns
    data = patdf.values.flatten()
    s = pd.Series(data)
    s = s.str.strip()
    s = s.values.reshape(patdf.shape)
    patdf = pd.DataFrame(s, columns=patdf.columns)
    patdf = patdf.fillna('0')
    patdf = patdf.replace('dischromic _patches', 'dischromic_patches')
    patdf = patdf.replace('spotting_ urination','spotting_urination')
    patdf = patdf.replace('foul_smell_of urine','foul_smell_ofurine')
    ind = [i for i in range(len(patdf))]
    symptoms = sevdf['Symptom'].unique()
    symptoms.shape
    symptoms = np.append(symptoms,'Disease')
    new_df = pd.DataFrame(columns = symptoms, index = ind)
    for i in range(len(ind)):
        row = patdf.values[i]
        new_row = [0 for l in range(len(symptoms))]
        for j in range(len(row)):
            symp = row [j]
            for k,sym in enumerate(symptoms):            
                if symp == sym:
                    new_row[k]=sevdf[sevdf['Symptom']==symp]['weight'].values[0]                
        new_row[-1]=row[0]
        new_df.loc[i]=new_row
    new_df    
    data = new_df.iloc[:,0:-1].values
    labels = new_df.iloc[:,-1].values
    data=np.asarray(data).astype(np.float32)
    x_train, x_test, y_train, y_test = train_test_split(data, labels, shuffle=True, train_size = 0.60)
    one = OneHotEncoder(sparse=False)
    y_train = y_train.reshape(y_train.shape[0],1)
    y_test = y_test.reshape(y_test.shape[0],1)
    one.fit(y_train)
    Y_train = one.transform(y_train)
    Y_test = one.transform(y_test)
    net = Sequential()
    net.add(Dense(20, activation='sigmoid', input_shape = x_train.shape[1:]))
    net.add(Dense(41, activation='softmax'))
    opt = Adam(lr=0.001)
    net.compile(
        loss='categorical_crossentropy', 
        optimizer=opt, 
        metrics=['accuracy'])
    history = net.fit(x_train, Y_train,
                        validation_data=(x_test, Y_test),
                        epochs = 50,
                        batch_size=32) 
    gnb = GaussianNB()
    gnb.fit(x_train, y_train)
    preds = gnb.predict(x_test)
    print('Accuracy:', accuracy_score(y_test,preds))
    print('F1 Score:',f1_score(y_test,preds,average='macro'))
    diseases = new_df.iloc[:,-1].values
    symptom = []
    n = 0
    for i in disDetails:
        symptom.append(i.get("Symp"))
        n = n + 1
    symptoms = sevdf['Symptom'].unique()
    samp_row = [0 for i in range(len(symptoms))]
    for i in range(len(symptom)):
        symp = symptom[i]
        for j,temp in enumerate(symptoms):
            if symp == temp:
                samp_row[j]=sevdf[sevdf['Symptom']==symp]['weight'].values[0]           
    tdf=np.array(samp_row).reshape(1, -1) 
    pred2 = gnb.predict(tdf)
    probs = gnb.predict_proba(tdf)
    net_pred = net.predict(np.array(tdf))
    predicted_val = one.inverse_transform(net_pred)
    print("Symptoms Entered:")
    for i in range(n):
        print("Symptom {}: {}".format(i+1,symptom[i]))
    print("\nPredicted Disease\n\nGaussian Naive Bayes: ", pred2[0])
    print("\nNeural Network:", predicted_val[0][0])
    diseases = new_df.iloc[:,-1].values
    diseases = np.unique(diseases)
    pred_probs = []
    for i in range(len(net_pred[0])):
        dict_new = {'Disease':diseases[i],'Prob':net_pred[0][i]}
        pred_probs.append(dict_new)
    sorted(pred_probs, key = lambda i: i['Prob'],reverse=True)
    dis_row = symdf[(symdf["Disease"] == predicted_val[0][0])]
    dis_row = dis_row.dropna(axis='columns')
    dis_row = dis_row.to_dict()
    print("dis_row")
    print(dis_row)
    print("dis_row")
    dis_desc_prec = []
    for i in list(range(len(list(dis_row.keys())) - 2)):
        if i == 0:
            dis_desc_prec.append({ 'can' : '', 'cov' : '',  'dis': dis_row.get('Disease').get(list(dis_row['Disease'].keys())[0]), 'desc': dis_row.get('Description').get(list(dis_row['Disease'].keys())[0]), 'precs': dis_row.get(list(dis_row.keys())[i + 2]).get(list(dis_row['Disease'].keys())[0]), 'dt': ""})
        else:
            dis_desc_prec.append({ 'can' : '', 'cov' : '',  'dis': '', 'desc': '', 'precs': dis_row.get(list(dis_row.keys())[i + 2]).get(list(dis_row['Disease'].keys())[0]), 'dt': ""})
    return dis_desc_prec


def predCancer(canDetails):
    candf = pd.read_csv("cancer-patient-data.csv")
    canX = candf.iloc[:,1:-1].values
    canY = candf.iloc[:,-1].values
    canXTr, canXTe, canYTr, canYTe = train_test_split(canX, canY, shuffle=True, train_size = 0.60)
    canYTr = canYTr.reshape(canYTr.shape[0],1)
    canYTe = canYTe.reshape(canYTe.shape[0],1)
    enc = OneHotEncoder(sparse=False)
    enc.fit(canYTr)
    CanYTr = enc.transform(canYTr)
    CanYTe = enc.transform(canYTe)
    model = Sequential()
    model.add(Dense(20, activation='sigmoid', input_shape = canXTr.shape[1:]))
    model.add(Dense(3, activation='softmax'))
    opt = Adam(lr=0.001)
    model.compile(
         loss='categorical_crossentropy', 
         optimizer=opt, 
         metrics=['accuracy'])
    history = model.fit(canXTr, CanYTr,
                    validation_data=(canXTe, CanYTe),
                    epochs = 50,
                    batch_size=32) 
    lab = LabelEncoder()
    lab.fit(canY)
    canY = lab.transform(canY)
    candf['Level'] = canY
    candf
    svm = SVC()
    svm.fit(canXTr, canYTr)
    canYPred = svm.predict(canXTe)
    print('Accuracy:', accuracy_score(canYTe,canYPred))
    print('F1 Score:',f1_score(canYTe,canYPred,average='macro'))
    feats = candf.columns[1:-1]
    x_sam = []
    x_sam.append(canDetails.get("age"))
    x_sam.append(canDetails.get("gender"))
    x_sam.append(canDetails.get("air_poll"))
    x_sam.append(canDetails.get("alc_use"))
    x_sam.append(canDetails.get("dust_all"))
    x_sam.append(canDetails.get("occ_Haz"))
    x_sam.append(canDetails.get("gen_ris"))
    x_sam.append(canDetails.get("ch_lu_dis"))
    x_sam.append(canDetails.get("bal_diet"))
    x_sam.append(canDetails.get("obese"))
    x_sam.append(canDetails.get("smoke"))
    x_sam.append(canDetails.get("pas_smo"))
    x_sam.append(canDetails.get("chest_pain"))
    x_sam.append(canDetails.get("cou_of_blo"))
    x_sam.append(canDetails.get("fatigue"))
    x_sam.append(canDetails.get("wei_Los"))
    x_sam.append(canDetails.get("sho_of_br"))
    x_sam.append(canDetails.get("whee"))
    x_sam.append(canDetails.get("swa_dif"))
    x_sam.append(canDetails.get("club_fina"))
    x_sam.append(canDetails.get("fre_cold"))
    x_sam.append(canDetails.get("dry_cou"))
    x_sam.append(canDetails.get("snore"))
    samp = np.array(x_sam).reshape(1, -1)
    print(samp)
    pred = svm.predict(samp)
    nn_pred = model.predict(samp)
    if pred == 0:
        pred = 'High'
    elif pred == 1:
        pred = 'Low'
    else:
        pred = 'Medium'
    print(nn_pred)
    print("\nPossibility of cancer:\nSVM:", pred)
    nn = np.argmax(nn_pred[0])
    if nn == 0:
        nn = 'High'
    elif nn == 1:
        nn = 'Low'
    else:
        nn = 'Medium'
    print("Neural Net:",nn)
    print('Probs:\nLow:{}\nMedium:{}\nHigh:{}'.format(nn_pred[0][1],nn_pred[0][2],nn_pred[0][0]))
    rfc = RandomForestClassifier()
    rfc.fit(canXTr,canYTr)
    pred = rfc.predict(samp)
    prob = rfc.predict_proba(samp)
    print('\nRandom Forest Classifier:', pred[0])
    print('Probs:\nLow:{}\nMedium:{}\nHigh:{}'.format(prob[0][1],prob[0][2],prob[0][0]))
    return nn


def predCovid(covDetails):
    covdf = pd.read_csv("both_test_balanced.csv")
    CovX = covdf.iloc[:,:-2].values
    CovY = covdf.iloc[:,-1].values
    covx_train, covx_test, covy_train, covy_test = train_test_split(CovX, CovY, shuffle=True, train_size = 0.60)
    covy_train = covy_train.reshape(covy_train.shape[0],1)
    covy_test = covy_test.reshape(covy_test.shape[0],1)
    enc = OneHotEncoder(sparse=False)
    enc.fit(covy_train)
    COVY_train = enc.transform(covy_train)
    COVY_test = enc.transform(covy_test)
    model = Sequential()
    model.add(Dense(20, activation='sigmoid', input_shape = covx_train.shape[1:]))
    model.add(Dense(2, activation='softmax'))
    opt = Adam(lr=0.001)
    model.compile(
        loss='categorical_crossentropy', 
        optimizer=opt, 
        metrics=['accuracy'])
    history = model.fit(covx_train, COVY_train,
                    validation_data=(covx_test, COVY_test),
                    epochs = 50,
                    batch_size=32) 
    svm = SVC()
    svm.fit(covx_train, covy_train)
    covy_pred = svm.predict(covx_test)
    print('Accuracy:', accuracy_score(covy_test,covy_pred))
    print('F1 Score:',f1_score(covy_test,covy_pred,average='macro'))
    print(classification_report(covy_test,covy_pred))
    cols = covdf.columns[:-2]
    sample = []
    sample.append(covDetails.get("th_Pa"))
    sample.append(covDetails.get("dys"))
    sample.append(covDetails.get("fev"))
    sample.append(covDetails.get("cou"))
    sample.append(covDetails.get("hea"))
    sample.append(covDetails.get("ta_di"))
    sample.append(covDetails.get("ol_di"))
    sample.append(covDetails.get("cor")) 
    sample.append(covDetails.get("gender")-1)
    sample = np.array(sample).reshape(1,-1)
    nn = model.predict(sample)
    predicted = svm.predict(sample)
    if predicted == 0:
        predicted = 'Negative'
    else:
        predicted = 'Positive'
    if np.argmax(nn) == 0:
        p = 'Negative'
    else:
        p = 'Positive'
    print('\nPredicted COVID report', predicted)
    print("Neural Network:", p)
    print("Probs:",nn)
    return p


def get_trust(cancer, disease, covid):
    DT = 5
    T = 0
    T1 = 0
    T2 = 0
    T3 = 0
    if disease in list(Comorbid):
        T1 = 1
    elif disease in list(Non_com): 
        T1 = 0

    if cancer == 'Low':    
        T2 = 0
    elif cancer == 'Medium':
        T2 = 1
    else:
        T2 = 2

    if covid == 'Positive':
        T3 = 1
    else:
        T3 = 0

    T = T1+T2+T3

    if (T == 0) or (T ==1 and T1 == 0 and T3 == 0):
        DT = 2
    elif (T == 1 and T1 == 1 and T3 == 0 ) or (T == 1 and T1 == 0 and T3 == 1) or (T == 1 and T1 == 0 and T2 == 1) or (T == 2 and T1 == 0 and T3 == 0) or (T == 2 and T1 == 1 and T3 == 0):
        DT = 1
    elif (T == 2 and T1 == 1 and T3 == 1) or T>2:
        DT = 0
        
    return DT

@app.errorhandler(500)
def resource_not_found(e):
    return jsonify(error=str(e)), 500

@app.route("/forgot", methods=['POST'])
@cross_origin()
def fgtPass():
    details = json.loads(request.data.decode('utf-8'))
    all_details = db.session.query(Profile).filter(Profile.EmailId == details.get("email"))
    sendDetails = {}
    for xdetails in all_details:
        sendDetails = {"loginId" : xdetails.LoginId, "password" : xdetails.Passw, "firstName" : xdetails.First_Name, "lastName" : xdetails.Last_Name, "gender" : xdetails.Gender, "dob" : xdetails.DOB, "age" : xdetails.Age, "address" : xdetails.Address, "email" : xdetails.EmailId, "secque1" : xdetails.Sec_Que1, "secque2" : xdetails.Sec_Que2, "secans1" : xdetails.Sec_Ans1, "secans2" : xdetails.Sec_Ans2 }   
    print(sendDetails)
    return jsonify(sendDetails)
    
    '''
    emailId = request.data.decode('utf-8')
    print(emailId)
    msg = Message(
                'Hello',
                sender ='yourId@gmail.com',
                recipients = ['reciever’sid@gmail.com']
               )
    msg.body = 'Hello Flask message sent from Flask-Mail'
    mail.send(msg)
    #return 'Sent'
    return jsonify(emailId)
    '''
#uptpwd   

@app.route("/uptpwd", methods=['POST'])
@cross_origin()
def updtPass():
    details = json.loads(request.data.decode('utf-8'))
    userResult = db.session.query(Profile).filter(Profile.LoginId == details.get("loginId"))
    for result in userResult:
        result.Passw = details.get("password")
    db.session.commit()
    return jsonify("Password Updated SuccessFully")

@app.route("/symps", methods=['GET'])
@cross_origin()
def getSymps():
    sympsdf = pd.read_csv("Symptom_Information.csv")
    sympsdf = sympsdf.replace(np.nan,"None")
    sympsdict = list(sympsdf.transpose().to_dict().values())
    return jsonify(sympsdict)

@app.route("/pre", methods=['POST'])
@cross_origin()
def prevReps():
    print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
    loginId = request.data.decode('utf-8')
    print(loginId)
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    repList = []
    reports = db.session.query(DisCanCov).filter(DisCanCov.LoginId == loginId)
    print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
    symdf = pd.read_csv("symp_desc_prec.csv")
    print("**********************************************************")
    for rep in reports:
        print("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^")
        dis_row = symdf[symdf["Disease"] == rep.Disease]
        print("######################################################")
        dis_row = dis_row.dropna(axis='columns')
        print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
        dis_row = dis_row.to_dict()
        print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        print(dis_row)
        dis_desc_prec = []
        for i in list(range(len(list(dis_row.keys())) - 2)):
            if i == 0:
                dis_desc_prec.append({ 'can' : rep.Level, 'cov' : rep.Result,  'dis': rep.Disease, 'desc': dis_row.get('Description').get(list(dis_row['Disease'].keys())[0]), 'precs': dis_row.get(list(dis_row.keys())[i + 2]).get(list(dis_row['Disease'].keys())[0]), 'dt': rep.Trust_Level})
            else:
                dis_desc_prec.append({ 'can' : '', 'cov' : '',  'dis': '', 'desc': '', 'precs': dis_row.get(list(dis_row.keys())[i + 2]).get(list(dis_row['Disease'].keys())[0]), 'dt': ""}) 
        repList.append(dis_desc_prec)
        print("((((((((((((((((((((((((((((((((((((((((((((((((((((((")
    print(repList)
    return jsonify(repList)    
    
    

@app.route("/login", methods=['POST'])
@cross_origin()
def auth():
     patlogs = []
     user = {}
     loginDetails = json.loads(request.data.decode('utf-8'))
     allpats = db.session.query(Profile).all()
     for ap in allpats:
         patlogs.append(ap.LoginId)
     if loginDetails.get("loginId") in patlogs:
         patientResult=db.session.query(Profile).filter(Profile.LoginId == loginDetails.get("loginId"))
         for result in patientResult:
             if result.Passw == loginDetails.get("password"):
                 user = {"loginId" : result.LoginId, "password" : result.Passw, "firstName" : result.First_Name, "lastName" : result.Last_Name, "gender" : result.Gender, "dob" : result.DOB, "age" : result.Age, "address" : result.Address, "email" : result.EmailId, "secque1" : result.Sec_Que1, "secque2" : result.Sec_Que2, "secans1" : result.Sec_Ans1, "secans2" : result.Sec_Ans2 }
             else:
                 user = { "Error" : "Incorrect password"}    
     else:
        user = {"Error" : "Login Id: " + loginDetails.get("loginId") + " is incorrect"} 
     return jsonify(user)
     
     
@app.route("/regi", methods=['POST'])
@cross_origin()
def register():
     regiDetails = json.loads(request.data.decode('utf-8'))
     patient = Profile(regiDetails.get("loginId"), regiDetails.get("password"), regiDetails.get("firstName"), regiDetails.get("lastName"), regiDetails.get("gender"), regiDetails.get("dob"), regiDetails.get("age"), regiDetails.get("address"), regiDetails.get("email"), regiDetails.get("secque1"), regiDetails.get("secque2"), regiDetails.get("secans1"), regiDetails.get("secans2"))
     db.session.add(patient)
     db.session.commit()
     return jsonify(regiDetails.get("loginId") + '  data sent successfully')
 

@app.route("/edit", methods=['POST'])
@cross_origin()
def editUser():
     userDetails = json.loads(request.data.decode('utf-8'))
     userResult = db.session.query(Profile).filter(Profile.LoginId == userDetails.get("loginId"))
     for result in userResult:
         result.Passw = userDetails.get("password")
         result.First_Name = userDetails.get("firstName")
         result.Last_Name = userDetails.get("lastName")
         result.Gender = userDetails.get("gender")
         result.DOB = userDetails.get("dob")
         result.Age = userDetails.get("age")
         result.Address = userDetails.get("address")
         result.EmailId = userDetails.get("email")
         result.Sec_Que1 = userDetails.get("secque1")
         result.Sec_Que2 = userDetails.get("secque2")
         result.Sec_Ans1 = userDetails.get("secans1")
         result.Sec_Ans2 = userDetails.get("secans2")
         user = {"loginId" : result.LoginId, "password" : result.Passw, "firstName" : result.First_Name, "lastName" : result.Last_Name, "gender" : result.Gender, "dob" : result.DOB, "age" : result.Age, "address" : result.Address, "email" : result.EmailId, "secque1" : result.Sec_Que1, "secque2" : result.Sec_Que2, "secans1" : result.Sec_Ans1, "secans2" : result.Sec_Ans2 }
         print(user)
         db.session.commit()
     return jsonify(user)
     

@app.route("/dcc", methods=['POST'])
@cross_origin()
def predAll():
    allDetails = json.loads(request.data.decode('utf-8'))
    disDetails = allDetails.get("firstForm")
    canDetails = allDetails.get("secondForm")
    covDetails = allDetails.get("thirdForm")
    symptoms = allDetails.get("symptoms")
    loginId = allDetails.get("loginId")
    resDis = predDisease(disDetails)
    resCan = predCancer(canDetails)
    resCov = predCovid(covDetails)
    resDis[0]["can"] = resCan
    resDis[0]["cov"] = resCov
    dt = get_trust(resDis[0]["dis"], resCan, resCov)
    resDis[0]["dt"] = dt
    results = resDis
    disCanCov = DisCanCov(allDetails.get("loginId"), symptoms[0], symptoms[1], symptoms[2], symptoms[3], symptoms[4], symptoms[5], symptoms[6], symptoms[7], symptoms[8], symptoms[9], symptoms[10], symptoms[11], symptoms[12], symptoms[13], symptoms[14], symptoms[15], symptoms[16], resDis[0].get("dis"), canDetails.get("age"), canDetails.get("gender"), canDetails.get("air_poll"), canDetails.get("alc_use"), canDetails.get("dust_all"), canDetails.get("occ_Haz"), canDetails.get("gen_ris"), canDetails.get("ch_lu_dis"), canDetails.get("bal_diet"), canDetails.get("obese"), canDetails.get("smoke"), canDetails.get("pas_smo"), canDetails.get("chest_pain"), canDetails.get("cou_of_blo"), canDetails.get("fatigue"), canDetails.get("wei_Los"), canDetails.get("sho_of_br"), canDetails.get("whee"), canDetails.get("swa_dif") ,canDetails.get("club_fina"), canDetails.get("fre_cold"), canDetails.get("dry_cou"), canDetails.get("snore"),resCan, covDetails.get("th_Pa"), covDetails.get("dys"), covDetails.get("fev"), covDetails.get("cou"), covDetails.get("hea"), covDetails.get("ta_di"), covDetails.get("ol_di"), covDetails.get("cor"), resCov, dt)
    db.session.add(disCanCov)
    db.session.commit()
    return jsonify(results)
        
   
if __name__ == '__main__':
    app.run(debug=False)
    db.create_all()
    app.run()